
<!DOCTYPE html>
<html lang="en">
  <head>
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <!-- Bootstrap CSS -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.0-beta1/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-giJF6kkoqNQ00vy+HMDP7azOuL0xtbfIcaT9wjKHr8RbDVddVHyTfAAsrekwKmP1" crossorigin="anonymous">
    <!--CSS-->
    <link rel="stylesheet" type="text/css" href="home.css">
    <link rel="preconnect" href="https://fonts.gstatic.com">
    <link href="https://fonts.googleapis.com/css2?family=Montserrat&display=swap" rel="stylesheet">

    <title>Home</title>
  </head>
  <body>
   <!--Navbar-->
   <nav class="navbar navbar-expand-lg navbar-dark bg-dark">
  <div class="container-fluid">
    <a class="navbar-brand" style="color: #00CB12"  href="index.php">Fitness Club</a>
    <div class="package" style="position: absolute;
    left: 12%;
    top: 10px;
    width: 9%;">
          <a class="nav-link " aria-current="page" style="
    /* position: absolute; */
    color: rgba(255,255,255,.55);
    left: 106px;
" href="Package.php">Packages</a>
</div>
<a class="nav-link " aria-current="page" href="admin/adminlayout.php" style="
    
    color: rgba(255,255,255,.55);
    left: 125px;
    position: absolute;
    left: 20%;
    top: 10px;
    width: 9%;"
">Workouts</a>
   
      <a href="members\sign_up.php"><button type="button" class="btn btn-success" >Sign-Up </button></a>
     
 
  </div>
</nav>
        </div><!--/.navbar-collapse -->
      </div>
    </div>
   </div>

    
    <div class="jumbotron">
    <table style="
    margin-top: 20px;
    font-size: 18px;"> <tr>
                <td align="right" valign="top"><table width="100%" style="
    margin-top: 31px; margin-left: 21%;
    font-size: 23px;
" border="0" cellspacing="0" cellpadding="0">
                  <tr>
                    <td align="right" valign="top"><table width="98%" border="0" cellspacing="0" cellpadding="0">
                      <tr></tr>
                      <tr>
                        <td align="left" valign="top"><table width="100%" border="0" cellspacing="0" cellpadding="0">
                          <tr>
                            <td align="left" valign="top" class="gray12_txt"><table width="100%" border="0" cellpadding="1" cellspacing="1">
                              <tr>
                                <td colspan="4" align="left" valign="top"><p><strong style="
    font-size: 26px;
"> Packages</strong></p></td>
                                </tr>
                              <tr>
                                <td width="25%" align="left" valign="top"><strong>Duration&nbsp; </strong></td>
                                <td width="25%" align="center" valign="top"><strong>General</strong></td>
                                <td width="25%" align="center" valign="top"><strong>Couple  </strong></td>
                                <td width="25%" align="center" valign="top"><strong>Happy Hours </strong></td>
                                </tr>
                              <tr>
                                <td width="522"><strong>Monthly&nbsp; </strong></td>
                                <td align="center" valign="top">1500 </td>
                                <td align="center" valign="top">2500 </td>
                                <td align="center" valign="top">1000 </td>
                                </tr>
                              <tr>
                                <td width="522"><strong>Quarterly&nbsp; </strong></td>
                                <td align="center" valign="top">3500</td>
                                <td align="center" valign="top">6500</td>
                                <td align="center" valign="top">2500</td>
                                </tr>
                              <tr>
                                <td width="522"><strong>Half-Yearly</strong></td>
                                <td align="center" valign="top">6500</td>
                                <td align="center" valign="top">11000</td>
                                <td align="center" valign="top">4500</td>
                                </tr>
                              <tr>
                                <td width="522"><strong>Yearly</strong></td>
                                <td align="center" valign="top">10000</td>
                                <td align="center" valign="top">18000</td>
                                <td align="center" valign="top">7500</td>
                                </tr>
                              </table></td>
                            </tr>
                          </table>
     
       <p><h5 style="
    margin-top: 118px;
"> <h3>Note:</h3>
» 	All Rates are in Indian Rs.<br>
» 	General Rates are applicable for Per Person Bases.<br>
» 	Couple Rates are applicable for Husband & Wife only.<br>
» 	Happy hours Rates are applicable between 11:00 am to 5:00 pm only.</p>
   
    </div>


 <div class="container">
      <!-- Example row of columns -->
  
      </div>


    
    </div> <!-- /container -->


    <!-- Bootstrap core JavaScript
    ================================================== -->
    <!-- Placed at the end of the document so the pages load faster -->
<script src="https://ajax.googleapis.com/ajax/libs/jquery/1.11.0/jquery.min.js"></script>
    <script src="boot/js/bootstrap.min.js"></script>
    <SCRIPT TYPE="text/javascript" src="http://code.jquery.com/jquery-1.9.1.js"></SCRIPT>
    <script type="text/javascript" src="http://code.jquery.com/ui/1.10.4/jquery-ui.js"></script>
 <SCRIPT src="boot/js/dialog.js" type="text/javascript"></SCRIPT>
<script type="text/JavaScript" src="boot/js/sha512.js"></script> 
        <script type="text/JavaScript" src="boot/js/forms.js"></script> 
      
    </script>
  </body>
</html>
