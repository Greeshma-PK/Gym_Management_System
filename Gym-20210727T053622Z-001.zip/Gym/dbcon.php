<?php 
$con=mysqli_connect('localhost','root','','gym');
if($con == false)
{
    echo "No connection with Database";
}
?>